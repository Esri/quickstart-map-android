/** Automatically generated file. DO NOT MODIFY */
package com.esri.template;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}